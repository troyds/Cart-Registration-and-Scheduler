﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace UserLogin
{
    internal class UserCheck
    {
        

        static void Reset()
        {
            /*txtbFirstName.Text = "";
            txtbLastName.Text = "";
            txtbAge.Text = "";
            txtbAddress.Text = "";
            txtbEmail.Text = "";
            txtbUsername.Text = "";
            txtbPassword.Text = "";
            txtbRetypePassword.Text = "";

            FrmLogin frmLogin = new FrmLogin();
            string username = frmLogin.loginUsername;
            string password = frmLogin.loginPassword;*/
        }
    }
}
